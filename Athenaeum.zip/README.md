<p align="center"><img src="./readme_asset/LogoMakr_7XONft.png" width="400"></p>



## About Athenaeum

Athenaeum is a private library management system that focuse on indexing collected books by their name, author, ISBN and genre.

## Technologies used
* Laravel
* Vue.js
* Bootstrap-vue

## How to deploy
** Coming soon **
