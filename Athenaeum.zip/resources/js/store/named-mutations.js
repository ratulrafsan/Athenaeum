import mutationTypes from './mutation-types';

const bookModule = 'book';

export default {
    BOOK_SET_QUERY : `${bookModule}/${mutationTypes.BOOK_SET_QUERY}`
}
