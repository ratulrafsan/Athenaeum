export default {
    'BOOK' : 'book',
    'AUTH' : 'auth',
    'AUTHOR' : 'author',
    'CATEGORY' : 'category',
    'USER' : 'user',
    'USERS' : 'users'
}
