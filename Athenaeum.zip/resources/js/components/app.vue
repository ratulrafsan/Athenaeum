<template>
    <v-app>
        <v-card>
            <v-card-title> Hello world :)</v-card-title>
        </v-card>
    </v-app>
</template>

<script>
    export default {
        name: "app.vue"
    }
</script>

<style scoped>

</style>
