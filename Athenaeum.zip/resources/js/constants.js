export default {
    'LocalStorageKeys' : {
        'TOKEN' : 'token',
        'USER' : 'user'
    }
}
