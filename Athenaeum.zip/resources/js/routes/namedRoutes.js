export default {
    'login' : '/login',
    'contact' : '/contact',
    'register' : '/register',
    'home' : '/home',
    'about' : '/about',
    'manageUser': '/manage/user',
    'addUser' : '/add/user',
    'addBook' : '/add/book',
    'editBook' : '/edit/book',
}
